8/10/17 - 9:58 AM
The partslist.dat file does not include rotation information.
Alternativly the main.mnt has rotation information.
The stencil file I named main.stc (I was not sure of the correct extention)

8/10/17 - 2:19 PM
I changed all of the footprints to be centered.
Re- DRD'd the design
Re- CAM'd the design
Note: partslist.dat DOES have orientation information

